# ☁️ Cloud-Based Energy Consumption Monitoring & Optimization System

**Author:** Nikesh Sinha (RA2311027010171)
**Institution:** SRM Institute of Science and Technology
**Aligns with:** UN SDG 7 — Affordable and Clean Energy

---

## 📋 Project Overview

A full-stack data science project that:

| Feature | Details |
|---|---|
| 📊 Real-time Dashboard | Live power, voltage, sub-metering charts |
| 🤖 AI Forecasting | Random Forest — predicts next 24 hours of demand |
| 🚨 Anomaly Detection | Isolation Forest — flags unusual consumption events |
| 🔔 Automated Alerts | Rule-based alerts for high usage, voltage faults, poor PF |
| 💡 Optimisation Tips | AI-generated energy-saving recommendations |
| 📈 Deep Analytics | Heatmaps, correlation matrix, monthly trends |

---

## 🗂️ Project Structure

```
energy_monitoring/
├── app.py               ← Streamlit dashboard (main entry)
├── data_processor.py    ← Load, clean, feature engineer, aggregate
├── ml_model.py          ← Forecasting + Anomaly detection models
├── alerts.py            ← Alert engine + optimisation tips
├── requirements.txt     ← Python dependencies
└── README.md
```

---

## 🚀 Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Place the dataset
Put `household_power_consumption.txt` in the same folder as `app.py`.

### 3. Run the dashboard
```bash
streamlit run app.py
```

The browser will open at **http://localhost:8501**

---

## 📦 Dataset

**UCI Household Power Consumption**
- ~2 million minute-level readings (2006–2010)
- Columns: Date, Time, Global_active_power, Global_reactive_power, Voltage,
  Global_intensity, Sub_metering_1, Sub_metering_2, Sub_metering_3

Download: https://archive.ics.uci.edu/ml/datasets/Individual+household+electric+power+consumption

---

## 🧠 ML Models

### Forecasting (Random Forest Regressor)
- **Features:** 48-hour lags, rolling mean/std (3h, 6h, 12h, 24h), hour of day, weekday flag, peak-hour flag
- **Split:** 80% train / 20% test (temporal, no leakage)
- **Output:** Predicted kW for next 24 hours

### Anomaly Detection (Isolation Forest)
- **Features:** All 7 sensor readings
- **Contamination:** Adjustable 1–10% (default 2%)
- **Output:** Normal / Anomaly label + anomaly score

---

## 🔔 Alert Thresholds (Configurable in Sidebar)

| Alert | Default |
|---|---|
| ⚠️ Warning power | 4.5 kW |
| 🔴 Critical power | 6.0 kW |
| Low voltage | < 210 V |
| High voltage | > 250 V |
| Low power factor | < 0.85 |
| High current | > 25 A |

---

## 🌐 Cloud Deployment (Optional)

To deploy on Streamlit Community Cloud:
1. Push this folder to a GitHub repo
2. Go to https://share.streamlit.io → "New app" → select `app.py`
3. Upload dataset via the sidebar file uploader

For AWS Lambda / API Gateway integration, the `data_processor.py` and `ml_model.py`
modules are designed to be importable independently as microservices.

---

## 📄 License
MIT — free for academic and personal use.
